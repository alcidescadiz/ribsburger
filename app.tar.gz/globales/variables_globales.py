carrito = {}

cantidad_carrito = {
    "cantidad" : 0
}